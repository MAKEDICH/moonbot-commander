"""Routers модуль"""
from . import auth, servers, commands

__all__ = ["auth", "servers", "commands"]

